package StepDefinition;

import CommonHelper.BaseClass;
import POM.page;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class Amazonteststeps extends BaseClass {

	   page pg;
	
	@Given("^Open the amazon URL in browser$")
    public void open_the_amazon_url_in_browser() throws Throwable {
		startbrowser();
	}

	
	
	 @Given("^Click Hamburger menu and select tv appliances electronics$")
	    public void click_hamburger_menu_and_select_tv_appliances_electronics() throws Exception {
               pg = new page(driver);
               pg.click_TV_appliances();
               
	 }
	 
	 

	 
	 @Then("^Select samsung brand and select high to low filter and check about this item$")
	    public void select_samsung_brand_and_select_high_to_low_filter_and_check_about_this_item() throws Throwable {
		 pg = new page(driver);
		 pg.switchtosamsungtvscreen();
		 
	 }
}
