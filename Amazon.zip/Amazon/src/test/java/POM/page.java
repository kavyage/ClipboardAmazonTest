package POM;

import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import CommonHelper.BaseClass;


public class page {
	
	WebDriver driver;
	
	BaseClass BC = new BaseClass();
	
	
	
	
	public page(WebDriver driver) {
		this.driver = driver;
	PageFactory.initElements(driver, this);
	
	}

	@FindBy(xpath = "//span[@class='hm-icon-label']")
	public WebElement All;
	
	@FindBy(xpath = "//div[normalize-space()='TV, Appliances, Electronics']")
	public WebElement TV;
	
	@FindBy(xpath = "//div[normalize-space()='digital content and devices']")
	public WebElement digital;
	
	@FindBy(xpath = "//a[normalize-space()='Televisions']")
	public WebElement television;
	
	@FindBy(xpath = "//span[normalize-space()='Brands']")
	public WebElement Brands;
	
	@FindBy(xpath = "//span[@class='a-size-base a-color-base'][normalize-space()='Samsung']")
	public WebElement SamsungBrands;
	
	@FindBy(xpath = "//span[@class='a-dropdown-prompt']")
	public WebElement dropdown;
	
	@FindBy(xpath = "//a[contains(text(),'High to Low')]")
	public WebElement hightolow;
	
	@FindBy(xpath = "//span[@class='a-price']")
	public List<WebElement> prices;
	
	
	@FindBy(xpath = "//div[@data-index='2']")
	public WebElement item2;
	
	@FindBy(xpath = "//h1[normalize-space()='About this item']")
	public WebElement aboutthisitem;
	
	
	public void click_TV_appliances() throws Exception {
		BC.Wait(3);
		BC.objfluentobjclick(All, 3, 3);
		BC.Wait(2);
		BC.scrolltoelement(digital);
		BC.movetowindows();
		BC.objfluentobjclick(TV, 3, 3);
		BC.objfluentobjclick(television, 3, 3);
		BC.handledefaultcontent();
		
	}
	
	
	public void switchtosamsungtvscreen() throws Exception {
		BC.Wait(3);
		BC.scrolltoelement(Brands);
		BC.objfluentobjclick(SamsungBrands, 3, 3);
		BC.scrolltoelement(dropdown);
		BC.objfluentobjclick(dropdown, 3, 3);
		BC.objfluentobjclick(hightolow, 3, 3);
		BC.Wait(2);
		BC.objfluentobjclick(item2, 3, 3);
		BC.movetowindows();
		BC.scrolltoelement(aboutthisitem);
		if(aboutthisitem.isDisplayed()) {
			System.out.println(aboutthisitem.getText());
			assertTrue(true);
		}
		
	}
}
