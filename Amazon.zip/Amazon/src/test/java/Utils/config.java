package Utils;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class config {
	
	Properties pro;	
	
	public config() {
		
		File fis = new File("./Config/config.properties");
		
		try {
			FileInputStream FI = new FileInputStream(fis);
			
			 pro = new Properties();
			 
			 pro.load(FI);
			
		} 
			
		 catch (Exception e) {
			
			 System.out.println("File not loaded" + e.getMessage());
		}
		
		
	}
	
	
	public String getdatafromconfig(String keytosearch) {
		
		return pro.getProperty(keytosearch);
	}

	
	public String Browsername() {
		
		return pro.getProperty("Browser");
	}
	
	public String AppUrl() {
		return pro.getProperty("URL");
	}
}
