package Utils;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Browserfactory {
	
	
	
	public static WebDriver startapp(String browser, WebDriver driver, String appurl) {
		
		
		if(browser.equalsIgnoreCase("Chrome")) {
			
			WebDriverManager.chromedriver().setup();
			driver= new ChromeDriver();
			
		}
		else if(browser.equalsIgnoreCase("Firefox")) {
			
			WebDriverManager.firefoxdriver().setup();
			driver= new FirefoxDriver();
		}
		
		else {
			System.out.println("Driver not supported");
		}
		
      driver.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
      driver.manage().window().maximize();
      driver.get(appurl);
      driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);

		return driver;
		
	}

	
	public static void driverquit(WebDriver driver) {
		driver.quit();
	}
}
