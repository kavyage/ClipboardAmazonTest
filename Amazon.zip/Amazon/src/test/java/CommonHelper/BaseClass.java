package CommonHelper;

import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import Utils.Browserfactory;
import Utils.config;
import io.cucumber.java.Scenario;

public class BaseClass {

	public config config;
	public static WebDriver driver;
	
	
	
	public void startbrowser() throws Exception {
		config = new config();
		driver=Browserfactory.startapp(config.Browsername(), driver, config.AppUrl());
		
	}
	
	
	public void Screenshot_OnFail(Scenario scenario) {
		
		if (scenario.isFailed()) {

			TakesScreenshot ts = (TakesScreenshot) driver;
			byte[] src = ts.getScreenshotAs(OutputType.BYTES);
			scenario.attach(src, "image/png", "screenshot");
			driver.quit();

		}	
		else {
			
			Browserfactory.driverquit(driver);
		}
	
	}
	
	
	public boolean objfluentobjclick(WebElement element, int timeout, int polltime) {
		
		
		@SuppressWarnings("deprecation")
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(timeout, TimeUnit.SECONDS)
				.pollingEvery(polltime, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);	
	
	try {
		wait.until(ExpectedConditions.visibilityOf(element));
		element.click();
	    return true;
	}
	catch(Exception e) {
		e.getMessage();
		return false;
		
	}
	}
	
	
	public void scrolltoelement(WebElement element) {
		
		try {
			((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", element);
			Thread.sleep(500);
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	
	public boolean movetowindows() {
		
		try {
			Set<String>windows=driver.getWindowHandles();
			
			for(String window: windows) {
				driver.switchTo().window(window);
				
			}
			return true;
		}
		catch (Exception e) {
			// TODO: handle exception
			return false;
		}
	}
	
	public void handledefaultcontent() {
		driver.switchTo().defaultContent();
	}
	
	
	public void Wait(long value) throws Exception{
		
		try {
			Thread.sleep(value * 1000);
		}
		catch (Exception e){
			
		}
	}
}
