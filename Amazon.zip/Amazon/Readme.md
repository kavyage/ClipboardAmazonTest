#Steps to Execute Test from workspace tools
1. Import the zip file (Amazon) file to the workspace
2. To start test, run TestRunner.java from src/test/java > Runner > TestRunner.java
3. End of the test, refer console for the output is logged


#Steps to Execute in local
1.	Download the Zip file and extract
2.	Set the path in cmd prompt and execute below command
3.	“mvn clean test”


#Test files details
##config.java
config.java reads the config.properties
##config.properties
config.properties contains the browser and url configurations
##Browserfactory.java
Browserfactory.java contains the methods to start and stop the browser
##BaseClass.java
BaseClass.java contains helper methods for page.java 
##Page.java
Page.java contains all the web elements 
##Amazon.feature
Amazon.feature contains the test features
##Amazonteststeps.java 
Amazonteststeps.java contains the test feature methods 
##TestRunner
TestRunner act as a bridge between FeatureFile and stepDefinition and execute the test


